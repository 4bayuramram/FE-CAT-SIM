import { Renderer, Program, Mesh, Triangle } from "ogl";
import { useEffect, useRef } from "react";
import "./SoftAurora.css";

function hexToVec3(hex) {
  const h = hex.replace("#", "");
  return [
    parseInt(h.slice(0, 2), 16) / 255,
    parseInt(h.slice(2, 4), 16) / 255,
    parseInt(h.slice(4, 6), 16) / 255,
  ];
}

const vertexShader = `
attribute vec2 uv;
attribute vec2 position;
varying vec2 vUv;

void main() {
  vUv = uv;
  gl_Position = vec4(position, 0.0, 1.0);
}
`;

const fragmentShader = `
precision highp float;

uniform float uTime;
uniform vec3 uResolution;
uniform float uSpeed;
uniform float uScale;
uniform float uBrightness;
uniform vec3 uColor1;
uniform vec3 uColor2;
uniform float uNoiseFreq;
uniform float uNoiseAmp;
uniform float uBandHeight;
uniform float uBandSpread;
uniform float uOctaveDecay;
uniform float uLayerOffset;
uniform float uColorSpeed;

#define TAU 6.28318

vec3 gradientHash(vec3 p) {
  p = vec3(
    dot(p, vec3(127.1, 311.7, 234.6)),
    dot(p, vec3(269.5, 183.3, 198.3)),
    dot(p, vec3(169.5, 283.3, 156.9))
  );
  vec3 h = fract(sin(p) * 43758.5453123);
  float phi = acos(2.0 * h.x - 1.0);
  float theta = TAU * h.y;
  return vec3(cos(theta) * sin(phi), sin(theta) * cos(phi), cos(phi));
}

float quinticSmooth(float t) {
  return t*t*t*(t*(t*6.0 - 15.0) + 10.0);
}

float perlin3D(float amplitude, float frequency, float px, float py, float pz) {
  float x = px * frequency;
  float y = py * frequency;

  float fx = floor(x);
  float fy = floor(y);
  float fz = floor(pz);
  float cx = ceil(x);
  float cy = ceil(y);
  float cz = ceil(pz);

  vec3 g000 = gradientHash(vec3(fx, fy, fz));
  vec3 g100 = gradientHash(vec3(cx, fy, fz));
  vec3 g010 = gradientHash(vec3(fx, cy, fz));
  vec3 g110 = gradientHash(vec3(cx, cy, fz));
  vec3 g001 = gradientHash(vec3(fx, fy, cz));
  vec3 g101 = gradientHash(vec3(cx, fy, cz));
  vec3 g011 = gradientHash(vec3(fx, cy, cz));
  vec3 g111 = gradientHash(vec3(cx, cy, cz));

  float d000 = dot(g000, vec3(x - fx, y - fy, pz - fz));
  float d100 = dot(g100, vec3(x - cx, y - fy, pz - fz));
  float d010 = dot(g010, vec3(x - fx, y - cy, pz - fz));
  float d110 = dot(g110, vec3(x - cx, y - cy, pz - fz));
  float d001 = dot(g001, vec3(x - fx, y - fy, pz - cz));
  float d101 = dot(g101, vec3(x - cx, y - fy, pz - cz));
  float d011 = dot(g011, vec3(x - fx, y - cy, pz - cz));
  float d111 = dot(g111, vec3(x - cx, y - cy, pz - cz));

  float sx = quinticSmooth(x - fx);
  float sy = quinticSmooth(y - fy);
  float sz = quinticSmooth(pz - fz);

  float lx00 = mix(d000, d100, sx);
  float lx10 = mix(d010, d110, sx);
  float lx01 = mix(d001, d101, sx);
  float lx11 = mix(d011, d111, sx);

  float ly0 = mix(lx00, lx10, sy);
  float ly1 = mix(lx01, lx11, sy);

  return amplitude * mix(ly0, ly1, sz);
}

float auroraGlow(float t, vec2 uv) {
  float noiseVal = 0.0;
  float freq = uNoiseFreq;
  float amp = uNoiseAmp;

  vec2 samplePos = uv * uScale;

  for (float i = 0.0; i < 3.0; i++) {
    noiseVal += perlin3D(amp, freq, samplePos.x, samplePos.y, t);
    amp *= uOctaveDecay;
    freq *= 2.0;
  }

  float yBand = uv.y * 10.0 - uBandHeight * 10.0;

  return 0.35 * exp(uBandSpread * (1.0 - abs(noiseVal + yBand)));
}

void main() {
  vec2 uv = gl_FragCoord.xy / uResolution.xy;
  float t = uSpeed * uTime;

  vec3 col = vec3(0.0);

  col += auroraGlow(t, uv) *
         uColor1 *
         (0.6 + 0.4 * sin(uv.x * 3.0 + uTime * uColorSpeed));

  col += auroraGlow(t + uLayerOffset, uv) *
         uColor2 *
         (0.6 + 0.4 * cos(uv.y * 2.0 + uTime * uColorSpeed));

  col *= uBrightness;

  // 🔥 clamp supaya tidak pernah jadi putih
  col = clamp(col, 0.0, 0.85);

  gl_FragColor = vec4(col, 1.0);
}
`;

export default function SoftAurora({
  speed = 0.6,
  scale = 1.5,
  brightness = 0.8,

  // 🔥 FIX COLOR DEFAULT (NO WHITE ANYMORE)
  color1 = "#00467f",
  color2 = "#00d4ff",

  noiseFrequency = 2.5,
  noiseAmplitude = 1.0,
  bandHeight = 0.5,
  bandSpread = 1.0,
  octaveDecay = 0.1,
  layerOffset = 0,
  colorSpeed = 1.0,
}) {
  const containerRef = useRef(null);

  useEffect(() => {
    // Hormati preferensi user yang mematikan animasi (aksesibilitas +
    // sinyal kuat kalau device/koneksi terbatas)
    const prefersReducedMotion = window.matchMedia?.(
      "(prefers-reduced-motion: reduce)"
    ).matches;
    if (prefersReducedMotion) return;

    if (!containerRef.current) return;

    const container = containerRef.current;

    // OPTIMASI 1: cap devicePixelRatio. Tanpa ini, di layar dpr 3 kita
    // render 9x lebih banyak piksel untuk shader yang sudah berat.
    // 1.5 masih tajam secara visual tapi jauh lebih ringan untuk GPU.
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);

    const renderer = new Renderer({ alpha: true, dpr });
    const gl = renderer.gl;
    gl.clearColor(0, 0, 0, 0);

    let program;

    function resize() {
      renderer.setSize(container.offsetWidth, container.offsetHeight);

      if (program) {
        program.uniforms.uResolution.value = [
          gl.canvas.width,
          gl.canvas.height,
          gl.canvas.width / gl.canvas.height,
        ];
      }
    }

    window.addEventListener("resize", resize);
    resize();

    const geometry = new Triangle(gl);

    program = new Program(gl, {
      vertex: vertexShader,
      fragment: fragmentShader,
      uniforms: {
        uTime: { value: 0 },
        uResolution: {
          value: [
            gl.canvas.width,
            gl.canvas.height,
            gl.canvas.width / gl.canvas.height,
          ],
        },
        uSpeed: { value: speed },
        uScale: { value: scale },
        uBrightness: { value: brightness },
        uColor1: { value: hexToVec3(color1) },
        uColor2: { value: hexToVec3(color2) },
        uNoiseFreq: { value: noiseFrequency },
        uNoiseAmp: { value: noiseAmplitude },
        uBandHeight: { value: bandHeight },
        uBandSpread: { value: bandSpread },
        uOctaveDecay: { value: octaveDecay },
        uLayerOffset: { value: layerOffset },
        uColorSpeed: { value: colorSpeed },
      },
    });

    const mesh = new Mesh(gl, { geometry, program });
    container.appendChild(gl.canvas);

    let animationFrameId;
    let isRunning = true;

    // OPTIMASI 2: cap frame rate ke ~30fps. Animasi aurora ini pelan dan
    // halus secara visual, tidak butuh 60/90/120fps device modern —
    // ini langsung memotong beban GPU sampai separuh atau lebih.
    const FRAME_INTERVAL = 1000 / 30;
    let lastFrameTime = 0;

    function update(time) {
      animationFrameId = requestAnimationFrame(update);

      if (!isRunning) return;

      if (time - lastFrameTime < FRAME_INTERVAL) return;
      lastFrameTime = time;

      program.uniforms.uTime.value = time * 0.001;

      renderer.render({ scene: mesh });
    }

    animationFrameId = requestAnimationFrame(update);

    // OPTIMASI 3: berhenti render saat tab/browser tidak aktif dilihat
    function handleVisibilityChange() {
      isRunning = !document.hidden;
    }
    document.addEventListener("visibilitychange", handleVisibilityChange);

    // OPTIMASI 4: berhenti render saat section ini di-scroll keluar
    // layar (mis. user sudah scroll ke section fitur/footer)
    const observer = new IntersectionObserver(
      ([entry]) => {
        isRunning = entry.isIntersecting && !document.hidden;
      },
      { threshold: 0 }
    );
    observer.observe(container);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", resize);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      observer.disconnect();
      container.removeChild(gl.canvas);
      gl.getExtension("WEBGL_lose_context")?.loseContext();
    };
  }, [
    speed,
    scale,
    brightness,
    color1,
    color2,
    noiseFrequency,
    noiseAmplitude,
    bandHeight,
    bandSpread,
    octaveDecay,
    layerOffset,
    colorSpeed,
  ]);

  return (
    <div
      ref={containerRef}
      className="soft-aurora-container"
      // Fallback statis: kalau WebGL/animasi tidak jalan (reduced-motion
      // atau device tidak support), tetap tampil gradient mirip aurora
      // alih-alih kosong/putih polos.
      style={{
        background: `linear-gradient(135deg, ${color1}, ${color2})`,
      }}
    />
  );
}
