import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import TypewriterText from "./TypewriterText";

// Deteksi mobile (breakpoint sama dengan Tailwind `md`), reaktif kalau
// layar di-resize/rotate.
function useIsMobile(breakpoint = 768) {
  const [isMobile, setIsMobile] = useState(
    typeof window !== "undefined" ? window.innerWidth < breakpoint : false
  );
  useEffect(() => {
    const mq = window.matchMedia(`(max-width: ${breakpoint - 1}px)`);
    const handler = (e) => setIsMobile(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, [breakpoint]);
  return isMobile;
}

// Parent: mengatur jeda (stagger) antar child saat muncul
const container = {
  hidden: {},
  show: {
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.1,
    },
  },
};

// Child: tiap elemen fade + slide up sedikit
const item = {
  hidden: { opacity: 0, y: 20 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

export default function HeroContent() {
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  // Sama seperti Hero.jsx, tapi arah berlawanan (kiri, bukan kanan).
  // Hanya dipakai di mobile -- di desktop x/opacity dikunci diam (0/1)
  // karena posisinya sudah pas.
  const { scrollY } = useScroll();
  const xMobile = useTransform(scrollY, [0, 500], [0, -220]);
  const opacityMobile = useTransform(scrollY, [0, 500], [1, 0]);

  const x = isMobile ? xMobile : 0;
  const scrollOpacityStyle = isMobile ? opacityMobile : 1;

  return (
    <motion.div
      style={{
        x,
        opacity: scrollOpacityStyle,
        willChange: "transform, opacity",
      }}
      className="text-white space-y-6 md:space-y-8"
      variants={container}
      initial="hidden"
      animate="show"
    >
      {/* HERO TITLE */}
      <motion.h1
        variants={item}
        className="
          relative
          font-merriweather font-extrabold
          text-3xl sm:text-4xl md:text-5xl lg:text-6xl
          leading-tight md:leading-[1.1]
          tracking-tight
        "
      >
        {/* GHOST: teks final penuh, invisible, cuma dipakai untuk
            "mengunci" tinggi h1 (termasuk saat wrap ke 2/3 baris)
            sesuai lebar layar. Tidak pernah berubah -> tidak ada
            reflow, jadi tombol di bawah tidak ikut bergerak. */}
        <span aria-hidden="true" className="invisible block">
          Selamat bertemu di papan peringkat...
        </span>

        {/* Teks yang benar-benar diketik, ditumpuk di atas ghost
            lewat absolute positioning -> perubahan panjang teks
            selama animasi tidak lagi mempengaruhi layout di luar h1 */}
        <span className="absolute inset-0">
          <TypewriterText
            text="Selamat bertemu di papan peringkat..."
            typingSpeed={45}
            pauseAfterTyping={1500}
          />
        </span>
      </motion.h1>

      {/* DESCRIPTION */}
      <motion.p
        variants={item}
        className="
          font-times
          text-sm sm:text-base md:text-lg
          text-blue-100n
          max-w-xl
          leading-relaxed
        "
      >
        Tidak ada bimbel mahal di sini. Kami hanya menyediakan tryout dan
        pembahasan lengkap, serta papan peringkat yang bantu kamu membandingkan
        kesiapanmu dengan peserta lain di berbagai daerah di seluruh Indonesia.
        Sudah siap? Yuk, mulai tryout sekarang!
      </motion.p>

      {/* BUTTONS */}
      <motion.div
        variants={item}
        className="flex flex-col sm:flex-row gap-3 sm:gap-4"
      >
        <motion.button
          onClick={() => navigate("/home/simulasi")}
          whileHover={{ backgroundColor: "rgba(255,255,255,0.1)" }}
          whileTap={{ scale: 0.97 }}
          className="px-6 sm:px-8 py-3 sm:py-4 bg-transparent border-2 border-white/30 text-white font-bold rounded-xl transition-colors duration-300 w-full sm:w-auto"
        >
          Tryout sekarang
        </motion.button>
      </motion.div>
    </motion.div>
  );
}
