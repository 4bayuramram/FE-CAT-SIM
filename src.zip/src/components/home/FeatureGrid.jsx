import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import GlareHover from "./GlareHover";
import {
  CardGiftcardRounded,
  SellRounded,
  LocalFireDepartmentRounded,
  PhoneIphoneRounded,
  VisibilityOffRounded,
  PictureAsPdfRounded,
} from "@mui/icons-material";

const container = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.1 },
  },
};

const item = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

const GLARE_CYCLE = 3; // detik, lama 1 putaran sapuan glare per kartu
const WAVE_STEP = 0.25; // jeda fase antar kartu (detik) — kecil = banyak overlap = terasa gelombang

export default function FeaturesGrid() {
  const features = [
    {
      icon: <CardGiftcardRounded />,
      title: "1 Paket Full, Gratis",
      desc: "Bukan cuma cicipan — coba 1 paket tryout lengkap (110 soal, 100 menit) tanpa bayar sepeser pun. Baru yakin? Lanjut ke paket HOTS berikutnya.",
    },
    {
      icon: <SellRounded />,
      title: "Harga yang Masih Masuk Akal",
      desc: "Mulai dari Rp 5.000 aja. Mau latihan SKD lengkap atau fokus TWK/TIU/TKP doang, semua bisa — biar kamu maksimalin bagian yang emang perlu.",
    },
    {
      icon: <LocalFireDepartmentRounded />,
      title: "Desain Soal HOTS – Ultra HOTS",
      desc: "Jujur aja, kalau tryout-nya aja udah susah, kamu bakal lebih siap dan gak kaget pas ketemu soal aslinya.",
    },
    {
      icon: <PhoneIphoneRounded />,
      title: "Bisa Tryout Lewat HP, Kapan Aja",
      desc: "Gak perlu laptop. Buka browser di HP kamu, langsung bisa latihan — di kosan, di angkot, di mana aja.",
    },
    {
      icon: <VisibilityOffRounded />,
      title: "Identitasmu Aman di Papan Peringkat",
      desc: "Mau tampil atau nggak di leaderboard, itu pilihan kamu sendiri. Bisa disembunyikan kapan pun kamu mau.",
    },
    {
      icon: <PictureAsPdfRounded />,
      title: "Ada Bukti PDF Kamu Udah Serius Latihan",
      desc: "Setiap kali selesai tryout, hasilnya bisa diunduh jadi PDF — skor, kekuatan, kelemahan, semua tercatat rapi. Bisa kamu simpan sendiri buat pantau progress.",
    },
  ];

  const sectionRef = useRef(null);

  // Lacak posisi section relatif viewport
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  });

  // EFEK "BREATHING": grid penuh (scale 1, opacity 1) saat berada di
  // tengah layar, lalu mengecil + memudar begitu discroll menjauh --
  // baik ke atas (belum sampai) maupun ke bawah (sudah lewat). Gaya
  // yang sama dengan TrustStatsSection, tapi dipakai di sini untuk
  // seluruh grid fitur.
  const gridScale = useTransform(
    scrollYProgress,
    [0, 0.35, 0.65, 1],
    [0.85, 1, 1, 0.85]
  );
  const gridOpacity = useTransform(
    scrollYProgress,
    [0, 0.35, 0.65, 1],
    [0.3, 1, 1, 0.3]
  );

  const glareDelayFor = (index) => index * WAVE_STEP;

  return (
    <section
      ref={sectionRef}
      className="py-16 md:py-24 bg-[#00467f] font-merriweather font-extrabold"
    >
      <style>{`
        @keyframes cardWaveLift {
          0% {
            transform: translateY(0px);
            filter: brightness(1);
          }
          50% {
            transform: translateY(-5px);
            filter: brightness(1.06);
          }
          100% {
            transform: translateY(0px);
            filter: brightness(1);
          }
        }
        .wave-card {
          animation-name: cardWaveLift;
          animation-timing-function: ease-in-out;
          animation-iteration-count: infinite;
          will-change: transform;
        }
      `}</style>
      <div className="max-w-6xl mx-auto px-4 md:px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="text-center mb-12 md:mb-16 space-y-3"
        >
          <h2 className="text-2xl md:text-4xl text-white font-extrabold">
            Apa yang kami persiapkan di sini buat kamu?
          </h2>
          <p className="text-white/80 max-w-2xl mx-auto text-sm md:text-base font-semibold">
            Aman banget! Kami selalu mengoptimalkan hal-hal yang mendukung
            kesiapan dan kebutuhan kamu saat di masa-masa mempersiapkan diri.
          </p>
        </motion.div>

        {/* Grid - dibungkus wrapper terpisah untuk efek scale+opacity
            kontinu (breathing) mengikuti scroll, sementara
            stagger-reveal per kartu di dalamnya tetap jalan sekali
            saat kartu pertama kali terlihat */}
        <motion.div style={{ scale: gridScale, opacity: gridOpacity }}>
          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
            variants={container}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, amount: 0.15 }}
          >
            {features.map((feat, index) => (
              <motion.div
                key={index}
                variants={item}
                whileHover={{ y: -6 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className="relative"
              >
                <div
                  style={{
                    animationDuration: `${GLARE_CYCLE}s`,
                    animationDelay: `${glareDelayFor(index)}s`,
                  }}
                  className="
                    wave-card
                    relative
                    p-6 md:p-8
                    rounded-2xl
                    border border-white/40
                    bg-transparent
                    text-white
                    hover:border-white
                    transition-colors duration-200
                  "
                >
                  <GlareHover
                    width="100%"
                    height="100%"
                    background="transparent"
                    borderRadius="1rem"
                    borderColor="transparent"
                    glareColor="#ffffff"
                    glareOpacity={0.3}
                    glareAngle={-30}
                    glareSize={300}
                    transitionDuration={800}
                    autoPlay
                    autoPlayDuration={GLARE_CYCLE * 1000}
                    autoPlayDelay={glareDelayFor(index) * 1000}
                    className="absolute inset-0"
                  />

                  {/* Icon */}
                  <div className="w-12 h-12 rounded-xl border border-white flex items-center justify-center mb-5">
                    <span className="text-white scale-110">{feat.icon}</span>
                  </div>

                  {/* Title */}
                  <h3 className="text-lg md:text-xl font-extrabold mb-3 text-white">
                    {feat.title}
                  </h3>

                  {/* Desc */}
                  <p className="text-white/80 text-sm md:text-base font-semibold leading-relaxed">
                    {feat.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}